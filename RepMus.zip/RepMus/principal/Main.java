package principal;
import java.util.Scanner;
import modelo.Album;
import modelo.Cancion;
import modelo.EP;
import modelo.Reproductor;

public class Main {
    public static void main(String[] args) {
        try(Scanner sc = new Scanner(System.in)){       
             Reproductor reproductor = new Reproductor();

        // --- Crea un Album --
        System.out.println("=== Crear un Album ===");
        System.out.print("Nombre del album: ");
        String nombreAlbum = sc.nextLine();

        System.out.print("Autor del album: ");
        String autorAlbum = sc.nextLine();

        System.out.print("Numero de canciones: ");
        int numCanciones = sc.nextInt();

        sc.nextLine(); // limpiar buffer

        Album album = new Album(nombreAlbum, autorAlbum, numCanciones);
        reproductor.agregarPlaylist(album);

        // --- Crea un EP ---
        System.out.println("\n=== Crear un EP ===");
        System.out.print("Nombre del EP: ");
        String nombreEP = sc.nextLine();

        System.out.print("Autor del EP: ");
        String autorEP = sc.nextLine();

        System.out.print("Duración total (minutos): ");
        double duracionEP = sc.nextDouble();

        sc.nextLine(); // limp bufer

        EP ep = new EP(nombreEP, autorEP, duracionEP);
        reproductor.agregarPlaylist(ep);

        // --- Crea una Cancion --
        System.out.println("\n=== Crear una Canción ===");
        System.out.print("Título de la canción: ");
        String tituloCancion = sc.nextLine();

        System.out.print("Artista: ");
        String artista = sc.nextLine();

        System.out.print("Duración (minutos): ");
        double duracion = sc.nextDouble();

        sc.nextLine(); 

        System.out.print("Género: ");
        String genero = sc.nextLine();

        Cancion cancion = new Cancion(tituloCancion, artista, duracion, genero);

        // Mostrar en el reproductor
        System.out.println("\n=== Playlists y Cancion ===");
        reproductor.mostrarPlaylists();
        System.out.println("\nCancion creada:");
        cancion.mostrarInfo();

        // Reproducir la canción
        System.out.println("\nReproduciendo cancion:");
        cancion.reproducir();

    }
}

}
