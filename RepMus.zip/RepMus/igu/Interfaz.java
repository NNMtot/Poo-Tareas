package igu;

public class Interfaz {
    // Interfaz proxima acualizacion
}
