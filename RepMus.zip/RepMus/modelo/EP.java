package modelo;

public class EP extends Playlist {
    private double duracionTotal;

    public EP(String nombre, String autor, double duracionTotal) {
        super(nombre, autor);
        this.duracionTotal = duracionTotal;
    }
//getter
    public double getDuracionTotal() { 
        return duracionTotal; }
//Setter
    public void setDuracionTotal(double duracionTotal) { 
        this.duracionTotal = duracionTotal; }

    @Override
    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Duración total: " + duracionTotal + " min");
    }
}
