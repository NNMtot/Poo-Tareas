package modelo;

public class Playlist {
    private String nombre;
    private String autor;

    public Playlist() {
        this.nombre = "";
        this.autor = "";
    }

    public Playlist(String nombre, String autor) {
        this.nombre = nombre;
        this.autor = autor;
    }
//GEtters
    public String getNombre() { 
        return nombre; }
         public String getAutor() { 
        return autor; }
        
//setters
    public void setNombre(String nombre) { 
        this.nombre = nombre; }
    public void setAutor(String autor) { 
        this.autor = autor; }

    public void mostrarInfo() {
    System.out.println("Playlist: " + nombre + " | Autor: " + autor);
}

}
