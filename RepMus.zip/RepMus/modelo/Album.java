package modelo;

public class Album extends Playlist {
    private int numeroCanciones;

    public Album(String nombre, String autor, int numeroCanciones) {
        super(nombre, autor);
        this.numeroCanciones = numeroCanciones;
    }

    public int getNumeroCanciones() { 
        return numeroCanciones; }
    public void setNumeroCanciones(int numeroCanciones) { 
        this.numeroCanciones = numeroCanciones; }

    @Override
    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Nmero de canciones: " + numeroCanciones);
    }
}
