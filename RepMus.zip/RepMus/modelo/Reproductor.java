package modelo;

import java.util.ArrayList;
import java.util.List;

public class Reproductor {
    private final List<Playlist> playlists;

    public Reproductor() {
        playlists = new ArrayList<>();
    }

    public void agregarPlaylist(Playlist p) {
        playlists.add(p);
        System.out.println(" Playlist agregada: " + p.getNombre());
    }

    public void mostrarPlaylists() {
        System.out.println("\n Playlists del reproductor:");
        for (Playlist p : playlists) {
            p.mostrarInfo();
            System.out.println("-----");
        }
    }
}
